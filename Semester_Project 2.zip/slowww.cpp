#include <iostream>
#include <string>
#include <vector>

using namespace std;

// Product class
class Product {
private:
    string name;
    int quantity;
    double price;

public:
    // Constructor
    Product(string n, int q, double p) {
        name = n;
        quantity = q;
        price = p;
    }

    // Getter methods
    string getName() {
        return name;
    }

    int getQuantity() {
        return quantity;
    }

    double getPrice() {
        return price;
    }
};

// ProductTracker class
class ProductTracker {
private:
    vector<Product> products;

public:
    // Add a new product
    void addProduct(string name, int quantity, double price) {
        Product newProduct(name, quantity, price);
        products.push_back(newProduct);
    }

    // Get product information by name
    Product getProduct(string name) {
        for (int i = 0; i < products.size(); i++) {
            if (products[i].getName() == name) {
                return products[i];
            }
        }
        // Return an empty product if not found
        return Product("", 0, 0.0);
    }
};

int main() {
    ProductTracker tracker;

    // Add products
    tracker.addProduct("Apple", 10, 1.99);
    tracker.addProduct("Banana", 5, 0.99);
    tracker.addProduct("Orange", 8, 1.49);

    // Get product information
    Product apple = tracker.getProduct("Apple");
    Product banana = tracker.getProduct("Banana");
    Product orange = tracker.getProduct("Orange");

    // Display product information
    cout << "Product: " << apple.getName() << endl;
    cout << "Quantity: " << apple.getQuantity() << endl;
    cout << "Price:" << apple.getPrice() << endl;

    cout << "Product: " << banana.getName() << endl;
    cout << "Quantity: " << banana.getQuantity() << endl;
    cout << "Price: " << banana.getPrice() << endl;

    cout << "Product: " << orange.getName() << endl;
    cout << "Quantity: " << orange.getQuantity() << endl;
    cout << "Price: " << orange.getPrice() << endl;

    return 0;
}

